
--user table
drop table users cascade constraints;
create table users (
    user_id  integer primary key,
    first_name  varchar2(25)  not null,
    last_name varchar2(25) not null,
    email varchar2(225) not null,
    is_admin  number(1),
    status	number(1),
    gender	varchar2(1),
    dob		date,
    password varchar2(100) not null

);

--trader table
drop table trader cascade constraints;
create table trader (
    trader_id	number(8) primary key,
    trader_name varchar2(25),
    description varchar2(225),
    user_id    number(8) references users(user_id)

);

--shop table
drop table shop cascade constraints;
create table shop (
    shop_id  number(8) primary key,
    shop_name  varchar2(25) not null,
    shop_location varchar2(25) not null,
    trader_id number(8) references trader(trader_id)
);

--product_type
drop table product_type cascade constraints;
create table product_type(
    product_type_id  number(8) primary key,
    product_type_name varchar2(25) not null,
    shop_id	number(8) references shop(shop_id)
);

--product table
drop table product cascade constraints;
create table product (
    product_id number(8) primary key,
    product_name  varchar2(25),
    description  varchar2(255),
    price	number(8,2),
    stock	number(8),
    min_order   number(8),
    max_order   number(8),
    product_image varchar2(255),
    quantity	  number(8),
    allergy_info varchar2(255),
    product_type_id number(8) references product_type(product_type_id)

);

--discount table
drop table discount cascade constraints;
create table discount (
    discount_id  number(8) primary key,
    price number(8),
    product_id number(8) references product(product_id)
    
);


--cart table
drop table cart cascade constraints;
create table cart (
    cart_id  number(8) primary key,
    user_id  number(8) references users(user_id),
    product_id number(8) references product(product_id)
);


--orders table
drop table orders cascade constraints;
create table orders (
    order_id  number(8) primary key,
    quantity  number(8),
    cart_id number(8) references product(product_id)
);


--payment table
drop table payment cascade constraints;
create table payment (
    invoice_id number(8) primary key,
    user_id number(8) references users(user_id),
    order_id number(8) references orders(order_id),
    slot_id  number(8) references collection_slot(slot_id)
);




--collection_slot table
drop table collection_slot cascade constraints;
create table collection_slot (
    slot_id  number(8) primary key,
    slot_time number(8),
    product_id number(8) references product(product_id)
    
);

--request table
drop table request cascade constraints;
create table request (
    request_id   number(8) primary key,
    user_id number(8),
    request varchar2(225)
);


