</main>
    </div>

    <script>
        var sideNav = document.getElementById("side-nav");

        function toggle_nav() {
            sideNav.classList.toggle("active");   
        }

        function subnavtoggle(x) {
            x.classList.toggle("nav-open");
        }
    </script>
</body>
</html>