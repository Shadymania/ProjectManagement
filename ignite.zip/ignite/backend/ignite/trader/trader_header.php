<?php 
session_start();
include '../includes/form.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type='text/css' href='../css/dashboard.css'/>
    <title>DASHBOARD</title>
</head>
<body>
    
    <div class="grid-container">
        <header class="header">
            <div class="header__search">Search..</div>
            <div class="header__avatar">Your face</div>
        </header>

        <div class="menu-icon" id="menu-icon" onclick="toggle_nav()">
                <i class="fas fa-bars"></i>
        </div>
        <aside class="sidenav" id="side-nav" >
                <div class="logo">LOGO HERE</div>
                <div class="sidenav__close-icon" onclick="toggle_nav()">
                    <i class="fas fa-times"></i>close icon
                </div>

                
                <ul class="sidenav__list">
                    <li class="sidenav__list-item"><a href="#home_page">Dashboard</a></li>
                    <li class="sidenav__list-item" onclick="subnavtoggle(this)">
                        <a href="#">Shop</a> <span>&#x25BC;</span>
                        <ul class="sub-nav" >
                            <li class="sub-nav-item"><a href="#">shop 1</a> </li>
                            <li class="sub-nav-item"><a href="#">shop 2</a></li>
                        </ul>
                    </li>
                    <li class="sidenav__list-item"><a href="#profile">Profile</a></li>

                </ul>
                    
        </aside>
         <!--MAIN CONTENTS THE CONTENTS-->
        <main class="main">