<?php
session_start();
include '../includes/form.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <title>IGNITE</title>
</head>
<body>
<div class="container logo-search-bar">
                    <div class="pd-6">
                        Logo here
                    </div>
            </div>

            <div class="login-signup-container">
                <div class="login-signup-box">
                    <div class="form-title"> BECOME A TRADER</div>
                    <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' enctype="multipart/form-data">
                    <label>Something that represents the products you sell(for example)</label>    
                    <input type='text' name="name"  value="<?php echo (isset($_POST['name'])) ? $_POST['name']: '';?>" placeholder="TRADER NAME"/>
                        <input type='text' name="mobile_num"  value="<?php echo (isset($_POST['mobile_num'])) ? $_POST['mobile_num']: '';?>" placeholder="MOBIE NUMBER"/>
                        <input type='text' name="pass1"  value="<?php echo (isset($_POST['pass1'])) ? $_POST['pass1']: '';?>" placeholder="PASSWORD"/>
                        <input type='text' name="pass2"  value="<?php echo (isset($_POST['pass2'])) ? $_POST['pass2']: '';?>" placeholder="CONFIRM PASSWORD"/>
                        <textarea name="description"> <?php echo (isset($_POST['description'])) ? $_POST['description']: 'Tell us about your products....';?></textarea>

                        <button type="submit" name="trader_register">SUBMIT</button><br>
                    </form>
                </div>

    </div>
</body>
</html>