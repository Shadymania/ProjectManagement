<?php include 'trader_header.php'; 

//store user id in the session and fetch the traders info from that user_id, If trader of that user_id
//is present than fetch all shop_id of that trader.

//with shop id again fetch all the product_type_id of a trader.

if(isset($_SESSION['trader_id'])) {
    echo "welcome ".$_SESSION['trader_name']." your status should be". $_SESSION['trader_status'];
}
else {
    echo "no trader session!";
}
?> 
    <h1>ADD PRODUCT</h1>
    <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' enctype="multipart/form-data">
        <label>Product Name: </label>
        <input type="text" name="name" value="<?php echo (isset($_POST['name'])) ? $_POST['name']: '';?>" required/><br>
        <label>Description</label>
        <textarea name="desc" required><?php echo (isset($_POST['desc'])) ? $_POST['desc']: '';?></textarea><br>
        <label>Price:</label>
        <input type="number" step="0.01" name="price" value="<?php echo (isset($_POST['price'])) ? $_POST['price']: '';?>"required/><br>
        <label>Quantity:</label>
        <input type="number" name="qtn" min="1" max="1500" value="<?php echo (isset($_POST['qtn'])) ? $_POST['qtn']: '';?>" required/><br>
        <label>Minimum order for purchase</label>
        <input type="number" name="min_order" value="<?php echo (isset($_POST['min_order'])) ? $_POST['min_order']: '';?>"/><br>
        <label>maximum order for purchase</label>
        <input type="number" name="max_order" value="<?php echo (isset($_POST['max_order'])) ? $_POST['max_order']: '';?>"/><br>
        <label>Allergy Info:</label>
        <textarea name="allergy_info"><?php echo (isset($_POST['allergy_info'])) ? $_POST['allergy_info']: '';?></textarea><br>
        <label for="cars">Choose product type:</label>
        <select id="cars" name="category">
            <option value="903">Leafy green</option>
        </select><br>
        <label>Choose thumbnail:</label>
        <input type="file" name="thumbnail" />
        <input type="submit" name="add_product" value="Add product">
    </form>

    <h1>DISPLAY PRODUCT</h1>

    <h1>ADD PRODUCT TYPE</h1>

    <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' enctype="multipart/form-data">
        <label>Product Type Name: </label>
        <input type="text" name="name" value="<?php echo (isset($_POST['name'])) ? $_POST['name']: '';?>" required/><br>
        <label>Description</label>
        <textarea name="desc" required><?php echo (isset($_POST['desc'])) ? $_POST['desc']: '';?></textarea><br>
        <label for="cars">Choose Shop:</label>
        <select id="cars" name="type">
            <option value="900">Vegetables</option>
        </select><br>
        <input type="submit" name="product_type_submit" value="Add product">
    </form>

<?php include 'trader_footer.php'; ?>
