<?php 
session_start();
include 'includes/form.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <title>Ignite</title>
</head>
<body>

<?php
    //for customers only
    if(isset($_SESSION['user_id'])) {
        $is_trader = $crud->check_column_data('trader', 'user_id', $_SESSION['user_id']);

        echo "Welcome ". $_SESSION['username'];

    if(!$is_trader) {?>
        <a href="trader_register.php">Become a trader</a>
    <?php } 

    if($is_trader) {?>
        <a href="trader.php">View dashboard</a>
    <?php } ?>

        <a href="login.php">logout</a>

        <?php 
    }
    //for non-members
    else {
        ?><a href="login.php"> Login</a>
        <a href="register.php">register</a><?php
    }?>


