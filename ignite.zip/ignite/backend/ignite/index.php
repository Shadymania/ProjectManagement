

<?php include 'header.php';?>

<h2>This is homepage</h2>


<?php include 'footer.php';?>
