<?php 
// $conn = oci_connect('ignite_ecommerce', 'Slimshady8', '//localhost/xe');
class Dbh {
    public $conn; 
    
    public function __construct() {
        $this->conn = oci_connect('IGNITEPORTAL', 'admin', '//localhost/xe');
        
        if(!$this->conn) {
            echo "Error Connecting to the database";
        }
    }

}

?>
