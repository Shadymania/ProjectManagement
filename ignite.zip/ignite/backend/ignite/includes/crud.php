<?php
include 'connection.php';


class CrudOperation extends Dbh {

    //method for inserting data inside table
    public function insert_record($table, $primary_key, $data) {
        $conn = $this->conn;
        $sql = "";
        $sql .= "INSERT INTO ".$table;
        $sql .= " ($primary_key, ".implode(", ", array_keys($data)).") VALUES ";
        $sql .= "(seq_id.nextval, '".implode("', '", array_values($data))."')";

        $query = oci_parse($conn, $sql);

        if(oci_execute($query)) return true;
        else return false;
    }
    

    //FETCH LOGIN USER DETAILS
    public function fetch_login_user($email, $pass) {
        $data=null;
        $conn = $this->conn;
        $sql = "SELECT * FROM USERS WHERE email='$email' AND password='$pass'";
        $query = oci_parse($conn, $sql);
        oci_execute($query);

        while($row = oci_fetch_assoc($query)) {
            $data = $row;
        }

        if($data) return $data;
        else return false;

    }

    //FETCH LOGIN TRADER DETAILS
    public function fetch_login_trader($name, $pass) {
        $data=null;
        $conn = $this->conn;
        $sql = "SELECT * FROM TRADER WHERE TRADER_NAME='$name' AND password='$pass'";
        $query = oci_parse($conn, $sql);
        oci_execute($query);

        while($row = oci_fetch_assoc($query)) {
            $data = $row;
        }

        if($data) return $data;
        else return false;

    }

    //CHECK COLUMNS VALUES
    public function check_column_data($table,$column,$column_data) {
        $data=[];
        $conn = $this->conn;
        $sql = "SELECT * FROM $table WHERE $column='$column_data'";
        $query = oci_parse($conn, $sql);
        oci_execute($query);

        while($row = oci_fetch_assoc($query)) {
            array_push($data, $row);
        }

        if(count($data) == 0)
        return false;
        else
        return $data;

    }
    

}

$crud = new CrudOperation;
