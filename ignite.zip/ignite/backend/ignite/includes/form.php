<?php 
include 'crud.php';

/**
 * ADD PRODUCT FORM
 */
if(isset($_POST['add_product'])) {
    $errors = [];
    $name = "";
    $desc = "";
    $price = 0;
    $qtn = 0;
    $stock= 1;
    $min_order = 0;
    $max_order = 0;
    $allergy_info = "";
    $product_type = 0;
    $path = "";

    if(!empty($_POST['name']) && !empty($_POST['desc']) && !empty($_POST['price']) 
        && !empty($_POST['qtn']) && !empty($_FILES["thumbnail"]["name"])) {

        $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
        $desc = filter_var($_POST['desc'], FILTER_SANITIZE_STRING);
        $qtn = filter_var($_POST['qtn'], FILTER_VALIDATE_INT);
        $min_order = filter_var($_POST['min_order'], FILTER_VALIDATE_INT);
        $max_order = filter_var($_POST['max_order'], FILTER_VALIDATE_INT);
        $allergy_info = filter_var($_POST['allergy_info'], FILTER_SANITIZE_STRING);
        $product_type = $_POST['category'];

        //image upload process begins

        $target_dir = "../img/";
        $target_file = $target_dir . basename($_FILES["thumbnail"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $check = getimagesize($_FILES["thumbnail"]["tmp_name"]);
    
    
        if($check !== false) {
            //echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            array_push($errors, "File is not an image.");
            $uploadOk = 0;
        }
    
        // Check if file already exists
        if (file_exists($target_file)) {
            //echo "Sorry, file already exists.";
            $uploadOk = 0;
        }
        // Check file size
        if ($_FILES["thumbnail"]["size"] > 500000) {
            array_push($errors, "Sorry, your file is too large.");
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            array_push($errors, "Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $target_file)) {
                $path = $target_file;

            } else {
                array_push($errors, "Sorry, there was an error uploading your file.");
            }
        }
        //image upload process ends
         
        //price validation and storing!
         if(filter_var($_POST['price'], FILTER_VALIDATE_FLOAT)) { 
            $price = $_POST['price'];
         }
         else {
             array_push($errors, "Invalid price!!");
         }

         //checking for any errors before proceeding to storing and inserting data
         if(count($errors) == 0) {

            $data = [
                'product_name' => $name,
                'description' => $desc,
                'price' => $price,
                'stock' => $stock,
                'min_order' => $min_order,
                'max_order' => $max_order,
                'product_image' => $path,
                'quantity' => $qtn,
                'allergy_info' => $allergy_info,
                'product_type_id' => $product_type
            ];
            
            if($crud->insert_record('product', 'product_id', $data)) echo "Record inserted";
            else echo "Record inserting failed!";
        }
        else {
            foreach($errors as $error) {
                echo $error;
            }
        }


    }
    else {
        array_push($errors, "Fill all the empty fields!!");
        echo "something is empty!";
    }

}//if isset('addproduct') closes

/**
 * LOGIN FORM
 */
if(isset($_POST['login_submit'])) {
    $errors= [];
    $data = "";
    $email = "";
    $pass = "";
    if(!empty($_POST['email']) && !empty($_POST['password'])) {
        if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $email = strtoupper($_POST['email']);
            $pass = md5($_POST['password']);

            $data = $crud->fetch_login_user($email, $pass);
        }
        else{
            array_push($errors, "Invalid email!");
        } 

    }
    else array_push($errors, "Email or password field left empty!");
    if(count($errors) == 0) {
        if($data) {
            
            $_SESSION['user_id'] = $data['USER_ID'];
            $_SESSION['username'] = $data['FIRST_NAME'];
            $_SESSION['is_admin'] = $data['IS_ADMIN'];
            $_SESSION['status'] = $data['STATUS'];
             header('location: index.php');

    
        }
        else {
            echo "user not found!!";
        }
    }
    else {
        //print errors?
    }


}//lgoin submission ends.

/**
 * REGISTER FORM
 */

if(isset($_POST['register_submit'])) {
    $errors = [];
    $f_name = "";
    $l_name = "";
    $email = "";
    $pass1 = "";
    $pass2 = "";
    $dob = "";
    $gender = "";

    //checks for empty fields
    if(!empty($_POST['f_name']) && !empty($_POST['l_name']) && !empty($_POST['email'])
    && !empty($_POST['pass1']) && !empty($_POST['pass2']) && !empty($_POST['agree'])) {
        //checks for invalid email
        if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            //checks for mismatched passwords
            if($_POST['pass1'] == $_POST['pass2']) {
                $f_name = filter_var($_POST['f_name'], FILTER_SANITIZE_STRING);
                $l_name = filter_var($_POST['l_name'], FILTER_SANITIZE_STRING);
                $email = strtoupper($_POST['email']);
                $pass1 = md5($_POST['pass1']);
                $pass2 = md5($_POST['pass2']);
                $dob = $_POST['dob'];
                $gender = $_POST['gender'];
                
                // echo $dob;
                $data = [
                    'first_name' => $f_name,
                    'last_name' => $l_name,
                    'email' => strtoupper($email),
                    'is_admin' => 0,
                    'status' => 0,
                    'gender' => $gender,
                    'dob' => $dob,
                    'password' => $pass1
                ];


            }//if for comfirming passwords
            else array_push["Password and Confirm Password Donot Match!!"];


        }//if for validating email
        else array_push($errors, "Invalid emails!");

        
    }//if for checking all required fiels are filled!
    else array_push($errors, "Fill all the required fields!!");

    //checking if email is already in use.
    if($crud->check_column_data('users', 'email', strtoupper($email))) {
        array_push($errors, "User with the email already exists!!");
    }

    if(count($errors) == 0) {
        if($crud->insert_record('users', 'user_id', $data)) {
            $user = $crud->fetch_login_user($email, $pass1);

            if($user) {
                $_SESSION['user_id'] = $user['USER_ID'];
                $_SESSION['username'] = $user['FIRST_NAME'];
                $_SESSION['is_admin'] = $user['IS_ADMIN'];
                $_SESSION['status'] = $user['STATUS'];
                header('location: index.php');
                }
                else {
                    echo "user doesn't exist!!";
                }
        
        } 
        else echo "Record inserting failed!";



    }
    else {
        foreach($errors as $error) {
            echo "$error </br>";
        }
    }


}//registration submission ends

/**
 * TRADER REGISTRATION FORM
 */
if(isset($_POST['trader_register']) && isset($_SESSION['user_id'])) {
    $errors = [];
    $name = "";
    $mob_num = "";
    $desc = "";
    $count = 25;
    $trader_details=[];

    
    if(!empty($_POST['name']) && !empty($_POST['mobile_num']) && !empty($_POST['description'])
    && !empty($_POST['pass1']) && !empty($_POST['pass2'])) {
        $name = "";
        $mobile_num = "";
        $desc = "";
        $status = 1;//one represents deactivated trader
        $pass1 = "";
        $pass2 = "";

            if($_POST['pass1'] == $_POST['pass2']) {
                $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
                $mobile_num = $_POST['mobile_num'];
                $desc = filter_var($_POST['description'], FILTER_SANITIZE_STRING);
                $pass1 = md5($_POST['pass1']);
            }
            else array_push($errors, "Passwords don't match!!");


        
        //checks if trader with the name already exists!
        if($crud->check_column_data('trader','trader_name', strtoupper($name))) {
            array_push($errors, "Trader with name '$name' already exist!!");

        }
        //checks if user is already a trader
        if($crud->check_column_data('trader', 'user_id', $_SESSION['user_id'])) {
            array_push($errors,"You are already a trader!");
        }

        if(count($errors) == 0){
            $data = [
                'trader_name' => strtoupper($name),
                'description' => $desc,
                'user_id' => $_SESSION['user_id'],
                'mobile' => $mobile_num,
                'password' => $pass1,
                'status' => $status
            ];

            if($crud->insert_record('trader', 'trader_id', $data)) {
                $trader_details= $crud->check_column_data('trader','trader_name', strtoupper($name));
                if($trader_details) {

                    $_SESSION['trader_id'] = $trader_details[0]['TRADER_ID'];
                    $_SESSION['trader_status'] = $trader_details[0]['STATUS'];
                    $_SESSION['trader_name'] = $trader_details[0]['TRADER_NAME'];

                    header('location: trader_dashboard.php');
                }
                //set session
                
            }
            else {
                echo "failed to register!!";
            }
    
        }
        else {
            foreach($errors as $error) {
                echo $error;
            }
        }

        

    }
}//trader_register submission ends.

/**
 * TRADER LOGIN
 */

 if(isset($_POST['trader_login_submit'])) {
    $errors = []; 
    $name = "";
    $pass = "";
    $data = [];//stores trader details.

    if(!empty($_POST['name']) && !empty($_POST['password'])) {

            $name = strtoupper($_POST['name']);
            $pass = md5($_POST['password']);

            $data = $crud->fetch_login_trader($name, $pass);

    }
    else array_push($errors, "Name or password field is left empty!");
    
    if(count($errors) == 0) {

            $_SESSION['user_id'] = $data['USER_ID'];//this allows to continue session as customer.
            $_SESSION['trader_name'] = $data['TRADER_NAME'];
            $_SESSION['trader_status'] = $data['STATUS'];
            $_SESSION['trader_id'] = $data['TRADER_ID'];

            //also fetching user data associated with trader and setting session variables.
            $user_data = $crud->check_column_data('users', 'user_id', $data['USER_ID']);
            if($user_data) {
                $_SESSION['username'] = $user_data[0]['FIRST_NAME'];
                $_SESSION['is_admin'] = $user_data[0]['IS_ADMIN'];
                $_SESSION['status'] = $user_data[0]['STATUS'];
            }
             header('location: trader_dashboard.php');

    
        }
        else {
            foreach ($errors as $error ) {
                echo "$error </br>";
            }
        }
    }//trader_login ends 

    if(isset($_POST['product_type_submit'])) {
        $name = "";
        $desc = "";
        $shop_id = 0;

        if(!empty($_POST['name']) && !empty($_POST['desc'])) {
            $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
            $desc = filter_var($_POST['desc'], FILTER_SANITIZE_STRING);
            $shop_id = $_POST['type'];

            $data = [
                'product_type_name' => $name,
                'shop_id' => $shop_id,
                'description' => $desc
            ];

            if($crud->insert_record('product_type', 'product_type_id', $data)) echo "product type inserted!!";
            else echo "Failed to insert product type";
        }
    }

